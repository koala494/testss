from  arabicstopwords import *
